/*
 * NexusMessage.h
 *
 *  Created on: Jun 21, 2016
 *      Author: juergen
 */

#ifndef NEXUSMESSAGE_H_
#define NEXUSMESSAGE_H_
#include <ostream>
#include <iomanip>
#include <cstring>

using namespace std;

/*
 *
 */
#define MAIOSIZE 8192 //4096

class NexusMessage
{
public:
	NexusMessage();
	virtual ~NexusMessage();

	unsigned char operator [] (int idx) const { if(idx < 0 || idx >= *this) throw; return _msg[idx];}
	operator int () const {int len = _msg[0] + (_msg[1] << 8) + (_msg[2] << 16); return len > 0xffff?4:len;}
	operator unsigned char* () {return _msg;}
	operator const unsigned char* () const {return _msg;}
	void clr() { memset(_msg,0,MAIOSIZE);}

	ostream& dump(ostream &os, int from, int to) const
	{
		int mode = 1;
		os << "msg[" << dec << setw(4) << (int) *this << "], from:" << from << ", to: " << to;
		for(int i = from; i < to; i++)
			if(isprint(_msg[i]))
			{
				if(mode)
				{
					os << " \"";
					mode = 0;
				}
				os << _msg[i];
			}
			else
			{
				if(!mode)
				{
					os << '\"';
					mode = 1;
				}
				os << ' ' << hex << setw(2) << setfill('0') << (unsigned) _msg[i];
			}
		if(!mode)
			os << '\"';
		return os;
	}

	friend ostream& operator << ( ostream &os, const NexusMessage& msg)
	{
		int mode = 1;
		os << "msg[" << dec << setw(4) << setfill(' ') << (int) msg << "],";
		for(int i = 3; i < msg; i++)
			if(isprint(msg[i]))
			{
				if(mode)
				{
					os << " \"";
					mode = 0;
				}
				os << msg[i];
			}
			else
			{
				if(!mode)
				{
					os << '\"';
					mode = 1;
				}
				os << ' ' << hex << setw(2) << setfill('0') << (unsigned) msg[i];
			}
		if(!mode)
			os << '\"';
		return os;
	}

protected:
	unsigned char _msg[MAIOSIZE];
};

#endif /* NEXUSMESSAGE_H_ */

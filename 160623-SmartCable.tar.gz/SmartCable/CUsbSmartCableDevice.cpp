/*
 * CUsbSmartCableDevice.cpp
 *
 *  Created on: Jun 22, 2016
 *      Author: juergen
 */

#include "CUsbSmartCableDevice.h"

#include <unistd.h>
#include<sys/socket.h>
#include <iostream>

CUsbSmartCableDevice::~CUsbSmartCableDevice()
{
	while(close())
		;
	libusb_unref_device(_dev);
}

CUsbSmartCableDevice::CUsbSmartCableDevice(libusb_device *dev)
:_dev(libusb_ref_device(dev))
,_handle(0)
,_ocrefcnt(0)
,_kerneldriver(0)
,_fd(-1)
,_running(false)
{
	struct libusb_config_descriptor *config;
	int r = libusb_get_config_descriptor 	(dev, 0, &config);
	if(r)
		throw;

	_BULK_OUT = config->interface[0].altsetting[0].endpoint[1].bEndpointAddress;
	_BULK_IN = config->interface[0].altsetting[0].endpoint[0].bEndpointAddress;
}

unsigned CUsbSmartCableDevice::open()
{
	int r;

	if(!_ocrefcnt)
	{
		if(libusb_open(_dev, &_handle))
			throw;

		++_ocrefcnt;

		_kerneldriver = libusb_kernel_driver_active(_handle, 0);

		if(_kerneldriver == 1)
			r = libusb_detach_kernel_driver (_handle, 0);

		r = libusb_claim_interface (_handle,0);
		if(r)
			throw;

		r = libusb_reset_device (_handle);
	}
	return _ocrefcnt;
}

unsigned CUsbSmartCableDevice::close()
{
	if(_ocrefcnt)
		if(!--_ocrefcnt)
		{
			libusb_release_interface(_handle,0);
			libusb_close(_handle);
		}
	return _ocrefcnt;
}

string CUsbSmartCableDevice::ReadString(unsigned id)
{
	unsigned char tmp[512];
	int r;

	open();
	r = libusb_get_string_descriptor_ascii(_handle, id, tmp, sizeof(tmp));
	close();

	if(r < 0)
		throw;

	return string((const char*)tmp);
}

string CUsbSmartCableDevice::Manufacturer()
{
	struct libusb_device_descriptor desc;
	if(!libusb_get_device_descriptor(_dev, &desc))
		return 	ReadString((unsigned) desc.iManufacturer);
	throw;
}

string CUsbSmartCableDevice::Product()
{
	struct libusb_device_descriptor desc;
	if(!libusb_get_device_descriptor(_dev, &desc))
		return 	ReadString((unsigned) desc.iProduct);
	throw;
}

string CUsbSmartCableDevice::SerialNumber()
{
	struct libusb_device_descriptor desc;
	if(!libusb_get_device_descriptor(_dev, &desc))
		return 	ReadString((unsigned) desc.iSerialNumber);
	throw;
}

void* CUsbSmartCableDevice::stop()
{
	void *res = 0;

	if(running())
	{
		if(pthread_cancel(_thread))
			throw;
		pthread_join(_thread, &res);
	}
	return res;
}

bool CUsbSmartCableDevice::start( int fd)
{
	if(!running())
	{
		_fd = fd;
		if(!pthread_create(&_thread, NULL, threadfunction , this))
			usleep(10000);
	}
	return running();
}

void CUsbSmartCableDevice::cleanup_handler(void *obj)
{
	CUsbSmartCableDevice *o = static_cast<CUsbSmartCableDevice*>(obj);

	o->close();
	o->_running = false;
}

void* CUsbSmartCableDevice::threadfunction(void *obj)
{
	CUsbSmartCableDevice *o = static_cast<CUsbSmartCableDevice*>(obj);

	return o->runner();
}

void *CUsbSmartCableDevice::runner()
{
	static int cleanup_pop_arg;
	int iosize, r;
	NexusMessage message;

	open();
	_running = true;

	pthread_cleanup_push(cleanup_handler, this);

	while(1)
	{
		message.clr();
		iosize=0;
		r = libusb_bulk_transfer(_handle, _BULK_IN, message, MAIOSIZE, &iosize, 0);
		if(r || iosize < 3 || iosize != message)
		{
			cerr << "libusb_bulk_transfer IN "  << iosize << ", ";
			message.dump(cerr,0,iosize);
			cerr << endl;
			break;
		}

		cout << "USB->TCP:" << message << endl;

		iosize = send(_fd, message, message, 0);
		if(iosize != message)
		{
			cerr << "tcp write size " << iosize << ", ";
			message.dump(cerr,0,iosize);
			cerr << endl;
			break;
		}
	}
	pthread_cleanup_pop(cleanup_pop_arg);
	return 0;
}

int  CUsbSmartCableDevice::write(const NexusMessage &message)
{
	int iosize=0;

	int r = libusb_bulk_transfer(_handle, _BULK_OUT,const_cast<unsigned char*>((const unsigned char*) message), message, &iosize, 0);
	if(r || iosize != message)
	{
		cerr << "libusb_bulk_transfer OUT " << iosize << ", ";
		message.dump(cerr,0,iosize);
		cerr << endl;
		throw;
	}
	return iosize;
}


/*
 * NexusMessage.cpp
 *
 *  Created on: Jun 21, 2016
 *      Author: juergen
 */

#include "NexusMessage.h"

NexusMessage::NexusMessage()
{
	// TODO Auto-generated constructor stub

}

NexusMessage::~NexusMessage()
{
	// TODO Auto-generated destructor stub
}
